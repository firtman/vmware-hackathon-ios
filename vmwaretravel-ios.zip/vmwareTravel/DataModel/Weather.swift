//
//  Weather.swift
//  vmwareTravel
//
//

import Foundation

class Weather {
    var cityName: String?
    var temperature: Double?
}
